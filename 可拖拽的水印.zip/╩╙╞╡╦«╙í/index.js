var drag_=false;
var D=new Function('obj','return document.getElementById(obj);')
var oevent=new Function('e','if (!e) e = window.event;return e')
function Move_obj(obj){
    var x,y;
    D(obj).onmousedown=function(e){
        drag_=true;
        with(this){
            style.position="absolute";
            var temp1=offsetLeft;
            var temp2=offsetTop;
            x=oevent(e).clientX;y=oevent(e).clientY;
            document.onmousemove=function(e){
                if(!drag_)return false;
                with(this){
                    style.left=temp1+oevent(e).clientX-x+"px";
                    style.top=temp2+oevent(e).clientY-y+"px";
                }
            }
        }
        document.onmouseup=new Function("drag_=false");
    }
}

function Text_obj(obj){
    D(obj).onkeyup=function(e){
        $("#watermark").text($(this).val());
        $("#watermark").css({"border":"1px #fff dashed"});
    }
}

$("#txt").blur(function(){
    $("#watermark").css({"border":""});
})